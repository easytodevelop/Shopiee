eshopApp.controller('editStudentData', function ($scope, addstudentData) {	
	
	
	$scope.saveitem = function(studentinfo){
			//console.log(studentData);
			//console.log(studentData);			
			//studentData.sddData.push(studentinfo);
			//console.log(studentData);		
			
		};
		
		
		
	
	$scope.cancelitem = function(){

			window.location = "index.html";
		};	
	
	
});